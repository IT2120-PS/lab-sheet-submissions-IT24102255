setwd("/Users/dexter_kr/Library/CloudStorage/OneDrive-SriLankaInstituteofInformationTechnology/Dexter's Shared Folder/Github Clones - SLIIT/Y2 S1/PS/Labsheet 06/IT24102255")

#Question 01
n <- 50
p <- 0.85
#Part i
#Binomial Distribution
#Here, random variable X has binomial distribution with n = 50 and p = 0.85

#Part ii
prob <- pbinom(46,50,0.85,lower.tail = FALSE)
print(prob)

#Question 02
#Part i
#Number of customer calls per hour on a given day that receives by a call center

#Part ii
#Poisson Distribution
#Here, random variable X has poisson distribution with lambda = 12
lambda <- 12
k <- 15
prob1 <- dpois(k, lambda)
print(prob1)
