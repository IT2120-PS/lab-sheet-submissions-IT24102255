getwd()
setwd("/Users/dexter_kr/Library/CloudStorage/OneDrive-SriLankaInstituteofInformationTechnology/Dexter's Shared Folder/Github Clones - SLIIT/Y2 S1/PS/Labsheet 07/IT24102255")

#Exercise
#Q1
punif(25, min = 0, max = 40, lower.tail = TRUE) - punif(10, min = 0, max = 40, lower.tail = TRUE)

#Q2
pexp(2, rate=0.33, lower.tail = TRUE)

#Q3
#i)
pnorm(130, mean=100, sd=15, lower.tail=TRUE)

#ii)
qnorm(0.05, mean = 100, sd=15, lower.tail = FALSE)